# Assessment Rubrics

## Class Participation
- **Excellent:** Consistently engages in discussions, provides insightful comments.
- **Good:** Regularly participates, some insightful contributions.
- **Needs Improvement:** Rarely participates, comments lack depth.

## Homework and Assignments
- **Excellent:** Detailed and accurate, demonstrates thorough understanding.
- **Good:** Mostly accurate, demonstrates understanding with minor errors.
- **Needs Improvement:** Incomplete or inaccurate, lacks understanding.